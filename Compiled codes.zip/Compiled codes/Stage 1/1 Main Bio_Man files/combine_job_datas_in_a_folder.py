import os
import pandas as pd
import glob


cwd = os.path.abspath('') 
files = os.listdir(cwd)  
"""
## Method 1 gets the first sheet of a given file
df = pd.DataFrame()
for file in files:
    if file.endswith('.xlsx'):
        df = df.append(pd.read_excel(file)) 
#df.head() 
df.to_excel('total_sales.xlsx')
"""

#GOAL: Read file, clean 0 values from job files, combine then and get data out of it for general, male and female

"""
import glob
import os
"""
#os.chdir('/mydir')
#df = pd.DataFrame()
def Main():
    df = pd.DataFrame()
    for file in files: #glob.glob('*job_data*.'):
        print(file)

    print("Hi")
    for file in glob.glob('*job_data*.csv'):
        print(file)

        parts = file.split('j')
        print(parts)
        nameonly = parts[0]
        print(nameonly)

        df = df.append(pd.read_csv(file))
        df.drop(df.index[df['End Time'] == 0], inplace=True)
        

        #df.drop(df.index[df['Manufacturing Time'] == 'Manufacturing Time'], inplace=True)
        #print(df.head())
        #print(df.size)

    df.to_csv('{}combined_data.csv'.format(nameonly))
    
    

    df_analysis=pd.DataFrame(columns=['Alpha Mean','Alpha Mean Male','Alpha Mean Female','Patient Target Blood Cell Mean','Patient Target Blood Cell Mean Male','Patient Target Blood Cell Mean Female','Cycle Time Mean','Cycle Time Mean Male','Cycle Time Mean Female'])


        #ANALYSIS PART

        #create a new df

        #what do you want to document in a row??
        

    alpha_mean = df['Alpha_low_mfg'].mean()
    series = df.groupby('Gender')['Alpha_low_mfg'].mean()
    alpha_mean_male = series[1]
    alpha_mean_female = series[0]

    series_2 = df.groupby('Gender')['Patient Trgt Bld Count'].mean()
    pat_bld_cell_mean = df['Alpha_low_mfg'].mean()
    pat_bld_cell_male_mean = series_2[1]
    pat_bld_cell_female_mean = series_2[0]

    cycle_time_mean = df['Cycle Time'].mean()
    series_3 = df.groupby('Gender')['Cycle Time'].mean()
    cycle_time_mean_male = series_3[1]
    cycle_time_mean_female = series_3[0]
        
    print("HI")
    print(series)
    print(type(series))
    print(series_2)
    print("POOOO")
    print(series_2[0])
    
        #print(alpha_mean,alpha_mean_male,alpha_mean_female)
        #print(pat_bld_cell_mean,pat_bld_cell_male_mean,pat_bld_cell_female_mean)


        #self.df_job=pd.DataFrame(columns=['Job_number','Alpha_low_mfg','Delta_mfg','Manufacturing Time', 'Gender','Blood vol','Patient Trgt Bld Count','Start_Time','Processing_Time','Rework Time','End Time','Cycle Time']) 
    df_analysis = pd.DataFrame(columns=['Run','Alpha Mean','Alpha Mean Male','Alpha Mean Female','Patient Target Blood Cell Mean','Patient Target Blood Cell Mean Male','Patient Target Blood Cell Mean Female','Cycle Time Mean','Cycle Time Mean Male','Cycle Time Mean Female'])

        #df_analysis[]

    to_append2 = [nameonly] + [alpha_mean] + [alpha_mean_male] + [alpha_mean_female] + [pat_bld_cell_mean] + [pat_bld_cell_male_mean] + [pat_bld_cell_female_mean] + [cycle_time_mean] + [cycle_time_mean_male] + [cycle_time_mean_female]
    b_series = pd.Series(to_append2, index = df_analysis.columns)
        #df_analysis = df_analysis.append(to_append2, ignore_index=True)
    df_analysis = df_analysis.append(b_series, ignore_index=True)
        #alpha values, patient_target, cycle time for pop, male and female;

    df_analysis.to_csv('{}analysis.csv'.format(nameonly))




        # for interaction plot
        #drop rows with 0 end time
        #take average for general, men and women
        #response variables? alpha, cycle time and patient target blood cell

        #copy code from analysis of data and generating graphs

    
    df.to_csv('{}combined_data.csv'.format(nameonly))
    
    



Main()

"""
#mean
for col in col

df = df.append(pd.read_excel(file))


df_mean = df["b"].mean()

#var
print(df.var()['age'])

#std dev


#quartiles
np.percentile(df.time_diff, 50)
np.percentile(s1, [25, 50, 75])
np.percentile(s1, [25, 50, 75], interpolation='midpoint')

#utilization


#idle



g = df.groupby('Group')
df['Expected'] = (g['Value1'].transform(lambda x: x.eq(7).any()))&(g['Value2'].transform(lambda x: x.eq(9).any()))



https://www.youtube.com/watch?v=DJJdikCk09A


sumif = df.query('Country == "Germany"')['Sales'].sum()
averageif = df.query('Country == "Germany"')['Sales'].mean()
countif = df.query('Country == "Germany" & Segment =="MId"')['Sales'].count()
"""