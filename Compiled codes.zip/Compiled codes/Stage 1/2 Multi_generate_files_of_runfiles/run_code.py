
"""
for i in range(5):


file2 = open("runfile_1.sh","r")
file1 = open("runfile.sh","a")
file1.write(" 1")
file1.close()
"""
i=2
for i in range(1,1001):
	file1=open("runfile_{}.sh".format(i),"a")
	file2=open("runfile.sh","r")

	file1.write(file2.read())
	text = "python BioMan_runfile.py "

	file1.write("{}{}".format(text,i))

	file1.close()
	file2.close()
#file3=open("runfile_5.sh","a")


"""

file1=open("runfile_0.sh","a")
file2=open("runfile.sh","r")

file1.write(file2.read())
file1.write(" 1")

file1.close()
file2.close()
#file3=open("runfile_5.sh","a")

"""